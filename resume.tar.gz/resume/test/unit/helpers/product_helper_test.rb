require 'test_helper'

class ProductHelperTest < ActionView::TestCase
end
