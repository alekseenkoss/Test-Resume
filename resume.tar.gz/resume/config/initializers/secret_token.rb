# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Resume::Application.config.secret_token = 'dd1ca33ea4e7a8ab26843ae778dbc4e20e86e62689ff9973c94b93eaad63190d9feee54920dfe8f1c1a4cc1014b5a40266b1a85572fcbeb6f5a6bb19c491854b'
